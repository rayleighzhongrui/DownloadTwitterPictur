import { Storage } from './src/utils/storage.js';

const DEFAULT_TWITTER_FORMATS = ['account', 'tweetId'];
const DEFAULT_PIXIV_FORMATS = ['authorName', 'illustId'];

const state = {
  pixivProxies: [],
  activeProxyId: null
};

function updateExample(containerId, exampleId) {
  const formats = getSelectedFormats(containerId);
  let exampleText = '';

  formats.forEach(format => {
    switch (format) {
      case 'account':
        exampleText += 'rayleighzhong_';
        break;
      case 'tweetId':
        exampleText += '88669977_';
        break;
      case 'tweetTime':
        exampleText += '20230810_';
        break;
      case 'authorName':
        exampleText += '萩森じあ_';
        break;
      case 'authorId':
        exampleText += '12345_';
        break;
      case 'illustId':
        exampleText += '88669977_';
        break;
      case 'downloadDate':
        exampleText += '20230811_';
        break;
      default:
        break;
    }
  });

  if (exampleId === 'twitterVideoExample') {
    exampleText = exampleText.slice(0, -1) + '_1920x1080.mp4';
  } else {
    exampleText = exampleText.slice(0, -1) + '.jpg';
  }

  document.getElementById(exampleId).textContent = exampleText;
}

function toggleSelection(containerId, exampleId, videoExampleId = null) {
  const container = document.getElementById(containerId);
  container.addEventListener('click', event => {
    const target = event.target;
    if (target.classList.contains('format-option')) {
      target.classList.toggle('selected');
      updateExample(containerId, exampleId);
      if (videoExampleId) {
        updateExample(containerId, videoExampleId);
      }
    }
  });
}

function getSelectedFormats(containerId) {
  const container = document.getElementById(containerId);
  const selectedOptions = container.querySelectorAll('.format-option.selected');
  return Array.from(selectedOptions).map(option => option.getAttribute('data-value'));
}

function showSuccessMessage() {
  const successMessage = document.getElementById('successMessage');
  successMessage.style.display = 'flex';
  setTimeout(() => {
    successMessage.style.display = 'none';
  }, 2000);
}

function initSelection(containerId, storedFormats) {
  const container = document.getElementById(containerId);
  storedFormats.forEach(format => {
    const option = container.querySelector(`[data-value="${format}"]`);
    if (option) {
      option.classList.add('selected');
    }
  });

  if (containerId === 'twitterFormat') {
    updateExample(containerId, 'twitterExample');
    updateExample(containerId, 'twitterVideoExample');
  } else {
    const exampleId = containerId === 'pixivFormat' ? 'pixivExample' : 'twitterExample';
    updateExample(containerId, exampleId);
  }
}

function bindTabs() {
  const tabs = document.querySelectorAll('.tab');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(btn => btn.classList.remove('active'));
      contents.forEach(content => content.classList.remove('active'));

      tab.classList.add('active');
      const targetId = `${tab.dataset.tab}-tab`;
      document.getElementById(targetId).classList.add('active');
    });
  });
}

function renderProxyList() {
  const list = document.getElementById('proxyList');
  list.innerHTML = '';

  if (state.pixivProxies.length === 0) {
    list.innerHTML = '<div class="empty-state">暂无代理配置</div>';
    return;
  }

  state.pixivProxies.forEach(proxy => {
    const item = document.createElement('div');
    item.className = 'proxy-item';

    const statusClass = proxy.enabled ? 'status-on' : 'status-off';
    const isActive = proxy.id === state.activeProxyId ? 'active' : '';

    item.innerHTML = `
      <div class="proxy-main ${isActive}">
        <div class="proxy-title">
          <span class="status-dot ${statusClass}"></span>
          <span class="proxy-name">${proxy.name}</span>
          ${isActive ? '<span class="proxy-badge">默认</span>' : ''}
        </div>
        <div class="proxy-domain">${proxy.domain}</div>
      </div>
      <div class="proxy-actions">
        <button class="btn-outline" data-action="test" data-id="${proxy.id}">测试</button>
        <button class="btn-outline" data-action="edit" data-id="${proxy.id}">编辑</button>
        <button class="btn-outline" data-action="delete" data-id="${proxy.id}">删除</button>
        <button class="btn-outline" data-action="default" data-id="${proxy.id}">设为默认</button>
      </div>
    `;

    list.appendChild(item);
  });
}

async function saveProxies() {
  await Storage.setSync({
    pixivProxies: state.pixivProxies,
    activeProxyId: state.activeProxyId
  });
  renderProxyList();
}

function openProxyDialog(mode, proxy = null) {
  const dialog = document.getElementById('proxyDialog');
  const title = document.getElementById('dialogTitle');
  const form = document.getElementById('proxyForm');

  dialog.dataset.mode = mode;
  dialog.dataset.id = proxy?.id || '';
  title.textContent = mode === 'edit' ? '编辑代理' : '添加代理';
  form.reset();

  if (proxy) {
    document.getElementById('proxyName').value = proxy.name;
    document.getElementById('proxyDomain').value = proxy.domain;
    document.getElementById('proxyPriority').value = proxy.priority || 1;
  }

  dialog.classList.add('open');
}

function closeProxyDialog() {
  const dialog = document.getElementById('proxyDialog');
  dialog.classList.remove('open');
  dialog.dataset.mode = '';
  dialog.dataset.id = '';
}

async function handleProxyAction(event) {
  const button = event.target.closest('button');
  if (!button) return;

  const action = button.dataset.action;
  const id = button.dataset.id;
  const proxy = state.pixivProxies.find(item => item.id === id);
  if (!proxy) return;

  if (action === 'edit') {
    openProxyDialog('edit', proxy);
    return;
  }

  if (action === 'delete') {
    state.pixivProxies = state.pixivProxies.filter(item => item.id !== id);
    if (state.activeProxyId === id) {
      state.activeProxyId = state.pixivProxies[0]?.id || null;
    }
    await saveProxies();
    return;
  }

  if (action === 'default') {
    state.activeProxyId = id;
    await saveProxies();
    return;
  }

  if (action === 'test') {
    button.disabled = true;
    button.textContent = '测试中...';
    try {
      const response = await fetch(`https://${proxy.domain}/index.html`, { method: 'HEAD', mode: 'no-cors' });
      console.log('Proxy test response:', response);
      button.textContent = '可用';
    } catch (error) {
      button.textContent = '失败';
    } finally {
      setTimeout(() => {
        button.disabled = false;
        button.textContent = '测试';
      }, 1500);
    }
  }
}

function renderLogs(logs) {
  const logList = document.getElementById('logList');
  logList.innerHTML = '';
  if (logs.length === 0) {
    logList.innerHTML = '<div class="empty-state">暂无错误日志</div>';
    return;
  }

  logs.forEach(log => {
    const item = document.createElement('div');
    item.className = 'log-item';
    item.innerHTML = `
      <div class="log-title">
        <span class="log-platform">${log.platform}</span>
        <span class="log-time">${new Date(log.timestamp).toLocaleString()}</span>
      </div>
      <div class="log-message">${log.action} - ${log.error}</div>
      <div class="log-url">${log.url}</div>
    `;
    logList.appendChild(item);
  });
}

async function loadLogs() {
  const { errorLogs = [] } = await Storage.getLocal('errorLogs');
  const platformFilter = document.getElementById('logPlatform').value;
  const filtered = platformFilter === 'all'
    ? errorLogs
    : errorLogs.filter(log => log.platform === platformFilter);
  renderLogs(filtered);
}

async function exportLogs() {
  const { errorLogs = [] } = await Storage.getLocal('errorLogs');
  const blob = new Blob([JSON.stringify(errorLogs, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  chrome.downloads.download({
    url,
    filename: `downloadtwitterpicture_logs_${timestamp}.json`
  }, () => {
    URL.revokeObjectURL(url);
  });
}

document.getElementById('saveButton').addEventListener('click', async () => {
  const twitterFormats = getSelectedFormats('twitterFormat');
  const pixivFormats = getSelectedFormats('pixivFormat');
  const twitterSwitchState = document.getElementById('twitterSwitch').checked;
  const pixivSwitchState = document.getElementById('pixivSwitch').checked;
  const notificationsEnabled = document.getElementById('notificationSwitch').checked;

  await Storage.setSync({
    twitterFilenameFormat: twitterFormats,
    pixivFilenameFormat: pixivFormats,
    twitterSwitchActive: twitterSwitchState,
    pixivSwitchActive: pixivSwitchState,
    notificationsEnabled
  });
  showSuccessMessage();
});

document.getElementById('addProxyBtn').addEventListener('click', () => {
  openProxyDialog('add');
});

document.getElementById('cancelProxyBtn').addEventListener('click', closeProxyDialog);

document.getElementById('proxyForm').addEventListener('submit', async event => {
  event.preventDefault();
  const dialog = document.getElementById('proxyDialog');
  const mode = dialog.dataset.mode;
  const id = dialog.dataset.id || `proxy-${Date.now()}`;
  const proxy = {
    id,
    name: document.getElementById('proxyName').value.trim(),
    domain: document.getElementById('proxyDomain').value.trim(),
    enabled: true,
    priority: parseInt(document.getElementById('proxyPriority').value, 10) || 1
  };

  if (mode === 'edit') {
    state.pixivProxies = state.pixivProxies.map(item => item.id === id ? proxy : item);
  } else {
    state.pixivProxies = [...state.pixivProxies, proxy];
    if (!state.activeProxyId) {
      state.activeProxyId = id;
    }
  }

  await saveProxies();
  closeProxyDialog();
});

document.getElementById('proxyList').addEventListener('click', handleProxyAction);

document.getElementById('autoSwitchProxy').addEventListener('change', async event => {
  await Storage.setSync({ autoSwitchProxy: event.target.checked });
});

document.getElementById('roundRobinProxy').addEventListener('change', async event => {
  await Storage.setSync({ roundRobinProxy: event.target.checked });
});

document.getElementById('logPlatform').addEventListener('change', loadLogs);

document.getElementById('clearLogs').addEventListener('click', async () => {
  await Storage.setLocal({ errorLogs: [] });
  loadLogs();
});

document.getElementById('exportLogs').addEventListener('click', exportLogs);

async function init() {
  const result = await Storage.getSync([
    'twitterFilenameFormat',
    'pixivFilenameFormat',
    'twitterSwitchActive',
    'pixivSwitchActive',
    'notificationsEnabled',
    'pixivProxies',
    'activeProxyId',
    'autoSwitchProxy',
    'roundRobinProxy'
  ]);

  const twitterFormats = result.twitterFilenameFormat || DEFAULT_TWITTER_FORMATS;
  const pixivFormats = result.pixivFilenameFormat || DEFAULT_PIXIV_FORMATS;
  const twitterSwitch = typeof result.twitterSwitchActive === 'undefined' ? true : result.twitterSwitchActive;
  const pixivSwitch = typeof result.pixivSwitchActive === 'undefined' ? true : result.pixivSwitchActive;
  const notificationsEnabled = typeof result.notificationsEnabled === 'undefined' ? true : result.notificationsEnabled;

  initSelection('twitterFormat', twitterFormats);
  initSelection('pixivFormat', pixivFormats);

  document.getElementById('twitterSwitch').checked = twitterSwitch;
  document.getElementById('pixivSwitch').checked = pixivSwitch;
  document.getElementById('notificationSwitch').checked = notificationsEnabled;

  state.pixivProxies = result.pixivProxies || [];
  state.activeProxyId = result.activeProxyId || state.pixivProxies[0]?.id || null;
  document.getElementById('autoSwitchProxy').checked = typeof result.autoSwitchProxy === 'undefined'
    ? true
    : result.autoSwitchProxy;
  document.getElementById('roundRobinProxy').checked = typeof result.roundRobinProxy === 'undefined'
    ? false
    : result.roundRobinProxy;

  renderProxyList();
  loadLogs();
  bindTabs();
}

toggleSelection('twitterFormat', 'twitterExample', 'twitterVideoExample');
toggleSelection('pixivFormat', 'pixivExample');

init();
